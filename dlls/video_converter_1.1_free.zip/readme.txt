NReco.VideoConverter (FFMpeg wrapper)
-------------------------------------
Visit http://www.nrecosite.com/video_converter_net.aspx for the latest information (change log, examples etc)
API documentation: http://www.nrecosite.com/doc/NReco.VideoConverter/